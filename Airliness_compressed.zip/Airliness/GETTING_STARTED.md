# 🎬 Getting Started - Step by Step

## Step 1: Prerequisites Check ✅

Make sure you have:
- [ ] Node.js (v14+) installed: `node --version`
- [ ] npm installed: `npm --version`
- [ ] MongoDB installed: Download from https://www.mongodb.com/try/download/community

---

## Step 2: MongoDB Setup 🗄️

### Windows:
1. Download MongoDB Community from official website
2. Run installer with default settings
3. MongoDB automatically starts as service

### Verify MongoDB:
```bash
mongod
```
You should see: `waiting for connections on port 27017`

---

## Step 3: Backend Installation 🔧

```bash
# Navigate to backend folder
cd backend

# Install all dependencies
npm install

# This will take 2-3 minutes...
```

### Create `.env` file in backend folder:

**Windows (Command Prompt):**
```batch
echo MONGODB_URI=mongodb://localhost:27017/airfare_db > .env
echo JWT_SECRET=airfare_secret_key_12345 >> .env
echo PORT=5000 >> .env
echo FRONTEND_URL=http://localhost:3000 >> .env
```

**Or create file manually:**
1. Right-click in `backend` folder
2. New → Text Document
3. Name it `.env`
4. Add these lines:
```
MONGODB_URI=mongodb://localhost:27017/airfare_db
JWT_SECRET=airfare_secret_key_12345
PORT=5000
FRONTEND_URL=http://localhost:3000
```

---

## Step 4: Frontend Installation 📱

```bash
# Navigate to frontend folder (from Airliness root)
cd frontend

# Install all dependencies
npm install

# This will take 2-3 minutes...
```

---

## Step 5: Start Services 🚀

### Terminal 1: MongoDB
```bash
mongod
```
Keep this running in background

### Terminal 2: Backend Server
```bash
cd backend
npm start
```
You should see: `Server running on port 5000`

### Terminal 3: Frontend Server
```bash
cd frontend
npm start
```
Browser should automatically open: `http://localhost:3000`

---

## Step 6: First Time User Test 🧪

### Register
1. Click "Register"
2. Fill in:
   - First Name: **John**
   - Last Name: **Doe**
   - Email: **john@test.com**
   - Password: **test12345**
   - Phone: **1234567890**
3. Click "Register"
4. Automatically logged in ✅

### Search Flights
1. On Dashboard, fill search form:
   - From: **London**
   - To: **Paris**
   - Departure: **2026-06-15**
   - Passengers: **1**
2. Click "Search Flights"
3. See flight results ✅

### File Compensation Claim
1. Click "Claims" in navigation
2. Fill form:
   - Flight Number: **BA123**
   - Delay Duration: **180**
   - Flight Distance: **300**
   - Delay Reason: **airline_fault**
   - Booking Date: **2026-06-15**
3. Click "Submit Claim"
4. See confirmation ✅

---

## Step 7: Database Verification 📊

### View Data in MongoDB:

```bash
# Open MongoDB shell
mongo

# Connect to database
use airfare_db

# View collections
show collections

# View documents
db.users.find()
db.flights.find()
db.compensationclaims.find()
```

---

## Troubleshooting Guide 🔧

### Issue: "MongoDB connection refused"
```
Error: connect ECONNREFUSED
```
**Solution:**
1. Make sure mongod is running
2. Type in new terminal: `mongod`
3. Restart backend

### Issue: "Port 5000 already in use"
```
Error: listen EADDRINUSE :::5000
```
**Solution (Windows):**
```bash
netstat -ano | findstr :5000
taskkill /PID [PID] /F
```

### Issue: "Cannot find module"
```
Error: Cannot find module 'express'
```
**Solution:**
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

### Issue: "Frontend won't connect to backend"
```
Error: Network Error at http://localhost:5000
```
**Solution:**
1. Check backend is running: http://localhost:5000/api/health
2. In frontend, check `src/utils/api.js` has correct URL
3. Hard refresh browser: Ctrl+Shift+R

### Issue: "Can't login"
```
Error: Invalid email or password
```
**Solution:**
1. Make sure you registered first
2. Use same email and password
3. Check capslock is off
4. Try registering new account

---

## Project Structure Overview 📁

```
Airliness/
├── backend/                    # API Server
│   ├── models/                # Database models
│   ├── controllers/           # Business logic
│   ├── routes/                # API endpoints
│   ├── middleware/            # Auth & validation
│   ├── utils/                 # Helper functions
│   ├── server.js              # Main file
│   ├── package.json
│   ├── .env                   # Configuration
│   └── node_modules/          # (auto-generated)
│
├── frontend/                   # React App
│   ├── src/
│   │   ├── components/        # React components
│   │   ├── pages/             # Page components
│   │   ├── styles/            # CSS files
│   │   ├── utils/             # Helper code
│   │   ├── App.js             # Main component
│   │   └── index.js           # Entry point
│   ├── public/
│   ├── package.json
│   └── node_modules/          # (auto-generated)
│
├── README.md                   # Main documentation
├── SETUP_GUIDE.md             # Detailed setup
├── PROJECT_SUMMARY.md         # Project overview
└── QUICK_REFERENCE.md         # Quick help
```

---

## Important Notes 📝

### Environment
- Backend: http://localhost:5000
- Frontend: http://localhost:3000
- Database: localhost:27017

### Default Test Data
- User: test@test.com / test12345
- Admin: admin@test.com / admin12345

### File Locations
- Database files: C:\data\db (MongoDB default)
- Project: c:\Users\sunee\OneDrive\Desktop\Airliness

### Ports Used
- Frontend: 3000
- Backend: 5000
- MongoDB: 27017

---

## Common Commands 🎯

```bash
# Install dependencies
npm install

# Start development server
npm start

# Stop server
Ctrl + C

# View npm logs
npm logs

# Clear cache
npm cache clean --force

# Reinstall packages
rm -rf node_modules
npm install

# Kill process on port
netstat -ano | findstr :5000
taskkill /PID [PID] /F

# Check MongoDB
mongo
```

---

## File Editing Guide 📝

### To Change Port:
**backend/.env**
```
PORT=8000
```

### To Change Database:
**backend/.env**
```
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/airfare_db
```

### To Change API URL:
**frontend/src/utils/api.js**
```javascript
const API_BASE_URL = 'http://your-server:5000/api';
```

---

## Next Steps 📚

1. ✅ Complete installation
2. ✅ Test each module
3. ✅ Explore code
4. ✅ Customize styles
5. ✅ Add more flight data
6. ✅ Deploy to production

---

## Support Resources 🆘

**Documentation:**
- README.md - Project overview
- SETUP_GUIDE.md - Detailed setup
- QUICK_REFERENCE.md - Quick tips

**Contacts:**
- Express Docs: https://expressjs.com
- React Docs: https://react.dev
- MongoDB Docs: https://docs.mongodb.com

**Common Issues:**
- Check browser console (F12)
- Check backend terminal
- Verify all services running
- Check .env file settings

---

## Performance Tips ⚡

1. Use Production build for frontend: `npm run build`
2. Use MongoDB indexes for queries
3. Implement caching for flights
4. Compress API responses
5. Use CDN for static files

---

## Security Best Practices 🔒

1. ✅ Change JWT_SECRET in production
2. ✅ Use HTTPS in production
3. ✅ Validate all inputs
4. ✅ Use environment variables
5. ✅ Keep dependencies updated
6. ✅ Implement rate limiting
7. ✅ Use CORS properly
8. ✅ Hash passwords with bcrypt

---

## You're All Set! 🎉

Your Airfare Analysis Platform is ready to use!

**Quick Start:**
```bash
# Terminal 1
mongod

# Terminal 2
cd backend && npm start

# Terminal 3
cd frontend && npm start
```

Visit: **http://localhost:3000**

**Enjoy! 🚀**
