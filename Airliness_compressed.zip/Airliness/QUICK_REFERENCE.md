# 🎯 Quick Reference Guide - Airfare Platform

## 🚀 Start Here

### 1. Installation (3 minutes)

```bash
# Backend
cd backend && npm install

# Frontend
cd frontend && npm install
```

### 2. Configuration (2 minutes)

**Backend `.env` file:**
```
MONGODB_URI=mongodb://localhost:27017/airfare_db
JWT_SECRET=your_secret_key_12345
PORT=5000
FRONTEND_URL=http://localhost:3000
```

### 3. Start Services (1 minute each)

```bash
# Terminal 1: MongoDB
mongod

# Terminal 2: Backend
cd backend && npm start

# Terminal 3: Frontend  
cd frontend && npm start
```

**Result:** Open http://localhost:3000

---

## 👤 User Roles

### Regular User
- Register/Login
- Search flights
- File compensation claims
- View notifications
- Manage profile

### Admin
- All user features +
- Review pending claims
- Approve/reject claims
- Manage flights
- View system statistics

---

## 📝 Sample Test Credentials

```
Email: test@example.com
Password: test12345

Email: admin@example.com
Password: admin12345
```

*(Register new account if needed)*

---

## 🧪 Testing Each Module

### Module 1: Auth
```
1. Go to /register
2. Fill: John, Doe, john@test.com, password123
3. Click Register
4. Auto-login and redirect to dashboard
```

### Module 2: Dashboard
```
1. After login, see dashboard
2. View quick links to features
3. See user greeting
```

### Module 3: Flight Comparison
```
1. Dashboard → Enter search details
2. From: London, To: Paris, Date: 2026-06-15
3. Click Search Flights
4. View results with prices and details
5. See airline, rating, on-time performance
```

### Module 4: Compensation Claims
```
1. Click "Claims" in navigation
2. Fill form:
   - Flight: BA123
   - Delay: 180 minutes
   - Distance: 300 km
   - Reason: airline_fault
   - Date: 2026-06-15
3. Submit
4. Get claim number and confirmation
5. View claim in claims list
```

### Module 5: Form Validation
```
Try submitting empty fields:
- See error messages
- Required field highlighting
- Type validation
```

### Module 6: Data Display
```
Claims page shows:
- Claim numbers
- Status (pending/approved)
- Amounts
- Dates
```

### Module 7: Notifications
```
1. Click "Notifications"
2. See notification list
3. Unread count badge
4. Mark as read, delete
5. Get updates from claim actions
```

### Module 8: File Upload
```
In claims:
1. Create claim first
2. Upload document option appears
3. Select file and upload
4. See confirmation
```

### Module 9: API Integration
```
All communication via:
- REST APIs
- Axios client
- JWT authentication
- Error handling
```

### Module 10: Admin Panel
```
1. Login as admin
2. Go to /admin
3. See statistics dashboard
4. Review pending claims
5. Approve/reject with notes
6. Manage flights
```

---

## 🎨 Color Scheme

```
Primary Blue: #667eea
Secondary Purple: #764ba2
Success Green: #2ecc71
Error Red: #e74c3c
Warning Orange: #ff9800
Info Blue: #3498db
```

---

## 📞 API Endpoints Quick Reference

```bash
# Authentication
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/profile
PUT    /api/auth/profile

# Flights
POST   /api/flights/search
GET    /api/flights/:id
POST   /api/flights/filter

# Claims
POST   /api/claims/create
GET    /api/claims
GET    /api/claims/:id
POST   /api/claims/:claimId/upload

# Notifications
GET    /api/notifications
PUT    /api/notifications/:id/read
GET    /api/notifications/unread-count

# Admin
GET    /api/admin/stats
GET    /api/admin/claims
PUT    /api/admin/claims/:id/approve
```

---

## 💡 Example Workflows

### Workflow 1: User Files Claim
```
1. User logs in
2. Navigates to /claims
3. Fills compensation form
4. Submits claim
5. Gets confirmation
6. Receives notification
7. Gets email notification
8. Checks /notifications
9. Admin reviews and approves
10. User gets approval notification
11. Claim shows as approved
```

### Workflow 2: Admin Manages System
```
1. Admin logs in
2. Goes to /admin
3. Sees statistics
4. Reviews pending claims
5. Clicks claim to review
6. Adds approval notes
7. Clicks approve
8. User gets notification
9. Check stats update
10. Manage flights if needed
```

### Workflow 3: User Searches Flights
```
1. User logs in
2. Dashboard loads
3. Enters search criteria
4. Clicks search
5. Results displayed
6. Can filter by price, rating
7. See comparison
8. Click select flight
9. Proceed to booking
10. Search saved in history
```

---

## 🛠 Troubleshooting

### Backend Won't Start
```
Error: ECONNREFUSED at port 5000

Solution:
1. Kill process: lsof -ti:5000 | xargs kill
2. Start again: npm start
```

### MongoDB Connection Failed
```
Error: connect ECONNREFUSED 127.0.0.1:27017

Solution:
1. Start MongoDB: mongod
2. Restart backend
```

### Frontend Can't Connect
```
Error: API connection failed

Solution:
1. Check backend is running: http://localhost:5000/api/health
2. Clear cache: Ctrl+Shift+Delete
3. Hard refresh: Ctrl+Shift+R
```

### Can't Login
```
Error: Invalid credentials

Solution:
1. Check email/password correct
2. Try registering new account
3. Check browser console for errors
```

---

## 📊 Key Calculations

### Compensation Amount
```javascript
Distance ≤ 1500 km → €250
Distance ≤ 3500 km → €400
Distance > 3500 km → €600

If delay < 3 hours: multiply by 0.5
If delay > 24 hours: multiply by 1.5

No compensation for: weather, force majeure
```

### Eligibility Rules
```javascript
✅ Delay ≥ 3 hours
✅ Airline fault reason
✅ Within 6 months of booking

❌ Weather or natural disaster
❌ Less than 3 hours delay
❌ Claim expired (>6 months)
```

---

## 🔑 Environment Variables

### Backend
```
MONGODB_URI        # Database connection
JWT_SECRET         # Token secret
PORT              # Server port (5000)
FRONTEND_URL      # Frontend address
EMAIL_USER        # Gmail address
EMAIL_PASSWORD    # Gmail app password
```

### Frontend
```
REACT_APP_API_URL # API base URL
```

---

## 📂 Important Files

```
Backend:
- server.js                    # Main server
- models/                      # Data schemas
- controllers/                 # Business logic
- utils/compensationUtils.js   # Calculations

Frontend:
- App.js                       # Main component
- utils/api.js                 # API client
- utils/authContext.js         # Auth state
- pages/                       # Pages
- components/                  # Components
```

---

## ✅ Checklist Before Using

- [ ] Node.js installed
- [ ] MongoDB installed and running
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] .env file created with correct values
- [ ] Both servers started
- [ ] Can access http://localhost:3000
- [ ] Can register new account
- [ ] Can login successfully

---

## 🎓 Learning Outcomes

After using this platform, you'll understand:

✅ Full-stack Node.js & React development
✅ MongoDB database design
✅ REST API creation
✅ JWT authentication
✅ Form validation and handling
✅ File uploads
✅ PDF generation
✅ Email notifications
✅ Admin dashboards
✅ Component architecture

---

## 📞 Quick Help

**Backend Issues?**
- Check terminal for error messages
- Verify port 5000 is free
- Ensure MongoDB is running

**Frontend Issues?**
- Open browser DevTools (F12)
- Check Console for errors
- Check Network tab for API calls

**API Issues?**
- Test endpoint: http://localhost:5000/api/health
- Check Authorization header
- Verify token in localStorage

**Database Issues?**
- Check MongoDB running: `mongod`
- View database: `mongo airfare_db`
- Reset database: delete `airfare_db` collection

---

## 🚀 Ready to Go!

You now have a complete, production-ready Airfare Analysis platform!

**Next Steps:**
1. Start the servers
2. Register an account
3. Test each module
4. Explore the code
5. Customize as needed
6. Deploy to production

**Happy coding! ✨**
