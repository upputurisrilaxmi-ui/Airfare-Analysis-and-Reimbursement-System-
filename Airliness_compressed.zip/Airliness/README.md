# Airfare Analysis and Reimbursement Platform

A comprehensive Node.js and React-based web application for flight comparison and delay compensation management.

## Project Structure

```
Airliness/
├── backend/              # Node.js/Express backend
│   ├── config/          # Configuration files
│   ├── models/          # MongoDB models
│   ├── controllers/     # Route controllers
│   ├── routes/          # API routes
│   ├── middleware/      # Authentication & validation
│   ├── utils/           # Utility functions
│   ├── server.js        # Main server file
│   └── package.json     # Dependencies
│
└── frontend/            # React frontend
    ├── public/          # Static files
    ├── src/
    │   ├── components/  # React components
    │   ├── pages/       # Page components
    │   ├── styles/      # CSS files
    │   ├── utils/       # Utility functions
    │   ├── App.js       # Main App component
    │   └── index.js     # Entry point
    └── package.json     # Dependencies
```

## 10 Modules Implemented

1. **Authentication & Authorization** - Secure user login/registration with role-based access
2. **Dashboard** - Home screen with quick navigation and summaries
3. **Flight Comparison Tool** - Search and compare flights across airlines
4. **Flight Delay Compensation System** - Calculate eligibility and manage compensation claims
5. **Claim & Search Forms** - Form validation for flight search and compensation claims
6. **Data Display** - Tables and cards with sorting, filtering, and pagination
7. **Notifications & Alerts** - Real-time feedback system for claim status
8. **File Handling** - Document upload and PDF report generation
9. **API Integration** - REST APIs with Axios for data communication
10. **Admin Panel** - System management and claim review

## Installation

### Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file:
```
MONGODB_URI=mongodb://localhost:27017/airfare_db
JWT_SECRET=your_jwt_secret_key_here
PORT=5000
FRONTEND_URL=http://localhost:3000
```

### Frontend Setup

```bash
cd frontend
npm install
```

## Running the Application

### Start MongoDB
```bash
mongod
```

### Start Backend
```bash
cd backend
npm start
```

Backend will run on: `http://localhost:5000`

### Start Frontend
```bash
cd frontend
npm start
```

Frontend will run on: `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Flights
- `POST /api/flights/search` - Search flights
- `GET /api/flights/:id` - Get flight details
- `POST /api/flights/filter` - Filter flights
- `GET /api/flights/history` - Get search history

### Compensation Claims
- `POST /api/claims/create` - Create compensation claim
- `GET /api/claims` - Get user claims
- `GET /api/claims/:id` - Get claim details
- `POST /api/claims/:claimId/upload` - Upload claim documents

### Notifications
- `GET /api/notifications` - Get notifications
- `PUT /api/notifications/:id/read` - Mark as read
- `PUT /api/notifications/mark-all-read` - Mark all as read
- `DELETE /api/notifications/:id` - Delete notification

### Admin
- `GET /api/admin/claims` - Get all claims
- `PUT /api/admin/claims/:id/approve` - Approve claim
- `PUT /api/admin/claims/:id/reject` - Reject claim
- `POST /api/admin/flights` - Add flight
- `PUT /api/admin/flights/:id` - Update flight
- `DELETE /api/admin/flights/:id` - Delete flight
- `GET /api/admin/stats` - Dashboard statistics

## Key Features

✈️ **Flight Comparison**
- Search flights by route and date
- Filter by price, layovers, rating, airline
- Real-time availability and pricing

💰 **Compensation Claims**
- Calculate compensation based on delay duration and distance
- EU Regulation 261/2004 compliance
- Document upload and PDF receipt generation

👤 **User Management**
- Secure authentication with JWT
- Role-based access control (User/Admin)
- Profile management

📢 **Notifications**
- Real-time claim status updates
- Email notifications
- Notification center with mark as read

📊 **Admin Dashboard**
- System statistics and analytics
- Claim review and approval workflow
- Flight inventory management

## Technologies Used

### Backend
- Node.js & Express.js
- MongoDB with Mongoose
- JWT for authentication
- PDFKit for PDF generation
- Nodemailer for email notifications

### Frontend
- React 18
- React Router v6
- Axios for API calls
- CSS3 for styling

## User Roles

### User
- Search and compare flights
- File compensation claims
- Track claim status
- Manage profile
- View notifications

### Admin
- Review pending claims
- Approve/reject claims
- Manage flights
- View system statistics
- Monitor user activity

## Default Test Accounts

Register a new account or use:
- Email: test@example.com
- Password: password123

## Development

### Prerequisites
- Node.js 14+
- MongoDB installed and running
- npm or yarn

### Making Requests

All API requests (except auth endpoints) require JWT token in header:
```
Authorization: Bearer <token>
```

## Future Enhancements

- Real-time flight data integration with APIs
- Advanced filtering and sorting options
- Payment gateway integration
- Email receipts for claims
- Mobile app version
- Multi-language support
- Analytics and reporting

## License

MIT License

## Support

For issues or questions, please contact support@airfare.com
