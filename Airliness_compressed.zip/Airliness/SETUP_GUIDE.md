# 🚀 Airfare Analysis Platform - Complete Setup Guide

## Overview

This is a **full-stack web application** with all 10 required modules implemented:

1. ✅ **Authentication & Authorization** 
2. ✅ **Dashboard**
3. ✅ **Flight Comparison Tool**
4. ✅ **Flight Delay Compensation System**
5. ✅ **Form Handling & Validation**
6. ✅ **Data Display**
7. ✅ **Notifications & Alerts**
8. ✅ **File Handling**
9. ✅ **API Integration**
10. ✅ **Admin Panel**

---

## Prerequisites

Ensure you have installed:
- **Node.js** (v14 or higher)
- **npm** (comes with Node.js)
- **MongoDB** (local or MongoDB Atlas)
- **Git** (optional)

### Download & Install MongoDB (Windows)
1. Visit: https://www.mongodb.com/try/download/community
2. Download MongoDB Community Server
3. Run installer and follow instructions
4. Start MongoDB service: `mongod` in terminal

---

## Installation & Setup

### Step 1: Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file with configuration
cat > .env << EOF
MONGODB_URI=mongodb://localhost:27017/airfare_db
JWT_SECRET=your_secret_key_12345
PORT=5000
FRONTEND_URL=http://localhost:3000
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
EOF

# Start MongoDB (in another terminal)
mongod

# Start backend server
npm start
```

Backend will be available at: **http://localhost:5000**

### Step 2: Frontend Setup

```bash
# Open new terminal, navigate to frontend
cd frontend

# Install dependencies
npm install

# Start React development server
npm start
```

Frontend will open at: **http://localhost:3000**

---

## 📋 Module Overview & Testing

### Module 1: Authentication & Authorization

**Location:** `/login`, `/register`

**Test Steps:**
1. Go to http://localhost:3000/register
2. Fill registration form:
   - First Name: John
   - Last Name: Doe
   - Email: john@example.com
   - Password: password123
   - Phone: 1234567890
3. Click "Register"
4. Automatically logged in and redirected to dashboard

**Features:**
- Secure password hashing (bcryptjs)
- JWT token authentication
- Role-based access (user/admin)
- Protected routes

---

### Module 2: Dashboard

**Location:** `/dashboard` (default home page)

**Features:**
- Welcome screen after login
- Quick navigation links
- Recent activity summary

---

### Module 3: Flight Comparison Tool

**Location:** `/dashboard` (main feature)

**Test Steps:**
1. On Dashboard, fill search form:
   - From: London
   - To: Paris
   - Departure: 2026-06-15
   - Passengers: 1
2. Click "Search Flights"
3. View results with:
   - Airline name and flight number
   - Price, duration, layovers
   - On-time performance, rating
4. Click "Select Flight" to book (placeholder)

**Features:**
- Real-time flight search
- Multiple filtering options
- Sorting by price, duration, rating
- Search history tracking

---

### Module 4: Flight Delay Compensation System

**Location:** `/claims`

**Test Steps:**
1. Click "Claims" in navigation
2. Fill compensation form:
   - Flight Number: BA123
   - Delay Duration: 180 (minutes)
   - Flight Distance: 300 (km)
   - Delay Reason: airline_fault
   - Booking Date: 2026-06-15
3. Click "Submit Claim"
4. See confirmation with claim number

**Features:**
- Automatic eligibility calculation
- EU Regulation 261/2004 compliance
- Compensation amount calculation
- PDF receipt generation
- Email notifications

**Compensation Algorithm:**
- Distance ≤ 1500 km: €250
- Distance ≤ 3500 km: €400
- Distance > 3500 km: €600
- Reduced 50% if delay < 3 hours
- Increased 50% if delay > 24 hours
- No compensation for weather/force majeure

---

### Module 5: Form Handling & Validation

**All forms include:**
- Client-side validation
- Server-side validation using express-validator
- Error messages
- Required field highlighting
- Data sanitization

**Forms:**
- Registration form
- Login form
- Flight search form
- Compensation claim form
- Profile update form

---

### Module 6: Data Display

**Features:**
- Flight results in card layout
- Claims list with status indicators
- Pagination support
- Sorting and filtering
- Responsive tables
- Status badges

---

### Module 7: Notifications & Alerts System

**Location:** `/notifications`

**Test Steps:**
1. Click "Notifications" in navigation
2. View all notifications
3. Click "Mark Read" to mark as read
4. Click "Delete" to remove
5. See unread count badge

**Features:**
- Real-time notifications
- Multiple notification types (success, error, warning, info)
- Mark as read/unread
- Auto-delete old notifications
- Email notifications for claims

---

### Module 8: File Handling

**Within Claims Page:**

**Test Steps:**
1. Create a compensation claim (see Module 4)
2. Once claim is created, upload documents:
   - Ticket receipt
   - Boarding pass
   - ID proof
   - Any supporting documents
3. Files stored securely
4. PDF receipts generated automatically

**Features:**
- Secure file upload
- Multiple file format support
- PDF receipt generation for claims
- Document storage and retrieval

---

### Module 9: API Integration

**Base URL:** `http://localhost:5000/api`

**All communications use:**
- REST APIs
- Axios HTTP client
- JWT authentication
- Error handling
- Loading states

**Example Request:**
```javascript
const response = await api.get('/api/flights/search', {
  params: {
    departure: 'London',
    arrival: 'Paris',
    departureDate: '2026-06-15'
  }
});
```

---

### Module 10: Admin Panel

**Location:** `/admin` (admin only)

**Test Steps:**
1. Create an admin account (or ask admin to set role in database)
2. Login with admin account
3. Navigate to admin panel
4. View system statistics:
   - Total users
   - Total flights
   - Claims summary
   - Compensation totals

**Admin Features:**

**Claim Management:**
1. View all pending claims
2. Click "Review" on any claim
3. Add notes/reasons
4. Click "Approve" or "Reject"
5. User receives notification and email

**Flight Management:**
1. Add new flights
2. Update existing flight details
3. Delete flights
4. View flight inventory

**Dashboard Stats:**
- Total users
- Total flights
- Total claims
- Pending/approved/rejected counts
- Total compensation paid

---

## 📊 Database Models

### User
```
- firstName, lastName
- email (unique)
- password (hashed)
- role (user/admin)
- phone, passportNumber
- profileImage
```

### Flight
```
- flightNumber (unique)
- airline, aircraft
- departure (airport, time, city)
- arrival (airport, time, city)
- duration, price
- seats, layovers
- onTimePerformance, rating
```

### CompensationClaim
```
- claimNumber (auto-generated)
- userId (reference to User)
- flightNumber
- delayDuration, flightDistance
- delayReason
- compensationAmount
- status (pending/approved/rejected/paid)
- documents array
- claimDate, approvalDate
```

### Notification
```
- userId (reference to User)
- type (success/error/warning/info)
- title, message
- relatedId, relatedType
- isRead
- createdAt, expiresAt
```

---

## 🔐 Security Features

✅ Password hashing with bcryptjs
✅ JWT token authentication
✅ Protected API routes
✅ Role-based access control
✅ Input validation and sanitization
✅ Error handling
✅ Secure file uploads
✅ CORS configuration

---

## 📁 Project File Structure

```
Airliness/
├── backend/
│   ├── config/              # Database config
│   ├── models/              # Mongoose models (5 models)
│   ├── controllers/         # Business logic (5 controllers)
│   ├── routes/              # API routes (5 route files)
│   ├── middleware/          # Auth & validation
│   ├── utils/               # Helper functions
│   ├── server.js            # Main server file
│   ├── package.json
│   ├── .env.example
│   └── README.md
│
├── frontend/
│   ├── src/
│   │   ├── components/      # React components (9 components)
│   │   ├── pages/           # Page components (6 pages)
│   │   ├── styles/          # CSS files (12 stylesheets)
│   │   ├── utils/           # API & auth utilities
│   │   ├── App.js
│   │   ├── index.js
│   │   ├── App.css
│   │   └── index.css
│   ├── public/
│   │   └── index.html
│   ├── package.json
│   └── README.md
│
├── README.md                # Main documentation
├── .gitignore
└── SETUP_GUIDE.md          # This file
```

---

## 🚨 Troubleshooting

### Issue: Backend won't start
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution:** Start MongoDB first
```bash
mongod
```

### Issue: Frontend can't connect to API
```
Error: Network Error
```
**Solution:** Ensure backend is running on port 5000
```bash
cd backend && npm start
```

### Issue: Authentication fails
```
Invalid token
```
**Solution:** 
- Clear localStorage: `localStorage.clear()`
- Login again
- Check JWT_SECRET in .env matches

### Issue: Can't upload files
```
403 Forbidden
```
**Solution:** 
- Create uploads directory: `mkdir uploads`
- Check file permissions

---

## 🎯 Key Endpoints to Test

### Authentication
```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/profile
PUT    /api/auth/profile
```

### Flights
```
POST   /api/flights/search
GET    /api/flights/:id
POST   /api/flights/filter
GET    /api/flights/history
```

### Claims
```
POST   /api/claims/create
GET    /api/claims
GET    /api/claims/:id
POST   /api/claims/:claimId/upload
```

### Admin
```
GET    /api/admin/stats
GET    /api/admin/claims
PUT    /api/admin/claims/:id/approve
PUT    /api/admin/claims/:id/reject
```

---

## 📱 Testing the Full Workflow

### 1. User Registration & Login
```
1. Register new account at /register
2. Login at /login
3. Verify token stored in localStorage
```

### 2. Search Flights
```
1. Go to /dashboard
2. Enter search criteria
3. Click search
4. View results
```

### 3. File Compensation Claim
```
1. Go to /claims
2. Fill compensation form
3. Submit claim
4. Check claim number received
5. View in claims list
```

### 4. Admin Approval
```
1. Login as admin
2. Go to /admin
3. Review pending claims
4. Approve/reject claim
5. View in stats
```

### 5. Check Notifications
```
1. Go to /notifications
2. See claim status updates
3. Check unread count
4. Mark as read
```

---

## 🔧 Customization

### Change Database
Update `.env`:
```
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/airfare_db
```

### Change Port
Update `.env`:
```
PORT=8000
```

### Add More Airlines
Add flights in `/backend/utils/sampleData.js` then seed database

### Customize Compensation Rules
Edit `/backend/utils/compensationUtils.js` function `calculateCompensation()`

---

## 📚 Technologies Stack

**Backend:**
- Node.js v18+
- Express.js v4.18+
- MongoDB v5.0+
- Mongoose v7.0+
- JWT (jsonwebtoken)
- Bcryptjs for password hashing
- PDFKit for PDF generation

**Frontend:**
- React v18.2
- React Router v6.10
- Axios v1.3
- CSS3 with responsive design

---

## ✨ All 10 Modules Summary

| # | Module | Status | Location |
|---|--------|--------|----------|
| 1 | Auth & Authorization | ✅ Complete | `/login`, `/register` |
| 2 | Dashboard | ✅ Complete | `/dashboard` |
| 3 | Flight Comparison | ✅ Complete | `/dashboard` (search) |
| 4 | Compensation System | ✅ Complete | `/claims` |
| 5 | Forms & Validation | ✅ Complete | All forms |
| 6 | Data Display | ✅ Complete | Cards, tables, lists |
| 7 | Notifications | ✅ Complete | `/notifications` |
| 8 | File Handling | ✅ Complete | Claim uploads |
| 9 | API Integration | ✅ Complete | Backend APIs |
| 10 | Admin Panel | ✅ Complete | `/admin` |

---

## 🎓 Learning Resources

- Express.js Docs: https://expressjs.com
- MongoDB Docs: https://docs.mongodb.com
- React Docs: https://react.dev
- JWT Guide: https://jwt.io

---

## 📞 Support

For issues or questions:
1. Check error messages in browser console (F12)
2. Check backend terminal for server errors
3. Review README files in each directory
4. Check API status at http://localhost:5000/api/health

---

## 🎉 You're All Set!

Your complete Airfare Analysis and Reimbursement Platform is ready!

**Quick Start:**
```bash
# Terminal 1: MongoDB
mongod

# Terminal 2: Backend
cd backend && npm install && npm start

# Terminal 3: Frontend
cd frontend && npm install && npm start
```

Visit: **http://localhost:3000**

Happy coding! 🚀
