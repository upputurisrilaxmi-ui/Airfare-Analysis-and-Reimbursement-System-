# Airfare Analysis - Backend API Documentation

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Setup Environment
Create `.env` file with:
```
MONGODB_URI=mongodb://localhost:27017/airfare_db
JWT_SECRET=your_secret_key
PORT=5000
```

### 3. Start MongoDB
```bash
mongod
```

### 4. Run Server
```bash
npm start
# or for development with auto-reload
npm run dev
```

Server runs on: `http://localhost:5000`

## API Routes

### Auth Routes (`/api/auth`)
- `POST /register` - Register new user
- `POST /login` - Login user
- `GET /profile` - Get user profile (protected)
- `PUT /profile` - Update profile (protected)

### Flight Routes (`/api/flights`)
- `POST /search` - Search flights
- `GET /:id` - Get flight details
- `POST /filter` - Filter flights by criteria
- `GET /history` - Get search history (protected)

### Claims Routes (`/api/claims`)
- `POST /create` - Create compensation claim (protected)
- `GET /` - Get user claims (protected)
- `GET /:id` - Get claim details (protected)
- `POST /:claimId/upload` - Upload documents (protected)

### Notification Routes (`/api/notifications`)
- `GET /` - Get notifications (protected)
- `PUT /:id/read` - Mark as read (protected)
- `PUT /mark-all-read` - Mark all as read (protected)
- `DELETE /:id` - Delete notification (protected)
- `GET /unread-count` - Get unread count (protected)

### Admin Routes (`/api/admin`)
- `GET /claims` - Get all claims (admin only)
- `PUT /claims/:id/approve` - Approve claim (admin only)
- `PUT /claims/:id/reject` - Reject claim (admin only)
- `POST /flights` - Add flight (admin only)
- `PUT /flights/:id` - Update flight (admin only)
- `DELETE /flights/:id` - Delete flight (admin only)
- `GET /stats` - Get dashboard stats (admin only)

## Authentication

Protected routes require JWT token in Authorization header:
```
Authorization: Bearer <token>
```

## Error Handling

All errors return JSON with message and details:
```json
{
  "message": "Error description",
  "error": "Error details"
}
```

## Database Models

- **User** - Stores user information and authentication
- **Flight** - Flight data including routes and pricing
- **CompensationClaim** - Compensation claims and status
- **Notification** - User notifications
- **SearchHistory** - Flight search records
