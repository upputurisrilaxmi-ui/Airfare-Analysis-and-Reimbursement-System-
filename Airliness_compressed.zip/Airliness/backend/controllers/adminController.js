const CompensationClaim = require('../models/CompensationClaim');
const Flight = require('../models/Flight');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { sendEmail } = require('../utils/emailService');

// Module 10: Admin Get All Claims
exports.getAllClaims = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;

    const filter = {};
    if (status) filter.status = status;

    const claims = await CompensationClaim.find(filter)
      .populate('userId', 'firstName lastName email')
      .sort({ claimDate: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await CompensationClaim.countDocuments(filter);

    res.json({
      totalClaims: total,
      currentPage: page,
      totalPages: Math.ceil(total / limit),
      claims
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch claims', error: error.message });
  }
};

// Module 10: Admin Approve Claim
exports.approveClaim = async (req, res) => {
  try {
    const { claimId } = req.params;
    const { approvalNotes } = req.body;

    const claim = await CompensationClaim.findByIdAndUpdate(
      claimId,
      {
        status: 'approved',
        approvalDate: new Date(),
        notes: approvalNotes
      },
      { new: true }
    );

    if (!claim) {
      return res.status(404).json({ message: 'Claim not found' });
    }

    // Create notification
    const notification = new Notification({
      userId: claim.userId,
      type: 'success',
      title: 'Claim Approved',
      message: `Your claim ${claim.claimNumber} has been approved. Compensation: €${claim.compensationAmount}`,
      relatedId: claim._id,
      relatedType: 'CompensationClaim'
    });
    await notification.save();

    // Send email
    const user = await User.findById(claim.userId);
    if (user) {
      await sendEmail(
        user.email,
        'Compensation Claim Approved',
        `Your claim has been approved. You will receive €${claim.compensationAmount} shortly.`
      );
    }

    res.json({
      message: 'Claim approved successfully',
      claim
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to approve claim', error: error.message });
  }
};

// Module 10: Admin Reject Claim
exports.rejectClaim = async (req, res) => {
  try {
    const { claimId } = req.params;
    const { rejectionReason } = req.body;

    const claim = await CompensationClaim.findByIdAndUpdate(
      claimId,
      {
        status: 'rejected',
        rejectionReason: rejectionReason,
        approvalDate: new Date()
      },
      { new: true }
    );

    if (!claim) {
      return res.status(404).json({ message: 'Claim not found' });
    }

    // Create notification
    const notification = new Notification({
      userId: claim.userId,
      type: 'warning',
      title: 'Claim Rejected',
      message: `Your claim ${claim.claimNumber} has been rejected. Reason: ${rejectionReason}`,
      relatedId: claim._id,
      relatedType: 'CompensationClaim'
    });
    await notification.save();

    // Send email
    const user = await User.findById(claim.userId);
    if (user) {
      await sendEmail(
        user.email,
        'Compensation Claim Rejected',
        `Your claim has been rejected. Reason: ${rejectionReason}`
      );
    }

    res.json({
      message: 'Claim rejected successfully',
      claim
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to reject claim', error: error.message });
  }
};

// Module 10: Admin Add Flight
exports.addFlight = async (req, res) => {
  try {
    const { flightNumber, airline, departure, arrival, duration, price, seats } = req.body;

    const flight = new Flight({
      flightNumber,
      airline,
      departure,
      arrival,
      duration,
      price,
      seats
    });

    await flight.save();

    res.status(201).json({
      message: 'Flight added successfully',
      flight
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to add flight', error: error.message });
  }
};

// Module 10: Admin Update Flight
exports.updateFlight = async (req, res) => {
  try {
    const { flightId } = req.params;
    const updateData = req.body;

    const flight = await Flight.findByIdAndUpdate(
      flightId,
      updateData,
      { new: true }
    );

    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    res.json({
      message: 'Flight updated successfully',
      flight
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update flight', error: error.message });
  }
};

// Module 10: Admin Delete Flight
exports.deleteFlight = async (req, res) => {
  try {
    const { flightId } = req.params;

    const flight = await Flight.findByIdAndDelete(flightId);
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    res.json({ message: 'Flight deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete flight', error: error.message });
  }
};

// Module 10: Admin Dashboard Statistics
exports.getDashboardStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalFlights = await Flight.countDocuments();
    const totalClaims = await CompensationClaim.countDocuments();
    const approvedClaims = await CompensationClaim.countDocuments({ status: 'approved' });
    const pendingClaims = await CompensationClaim.countDocuments({ status: 'pending' });
    const totalCompensation = await CompensationClaim.aggregate([
      { $match: { status: 'approved' } },
      { $group: { _id: null, total: { $sum: '$compensationAmount' } } }
    ]);

    res.json({
      totalUsers,
      totalFlights,
      totalClaims,
      approvedClaims,
      pendingClaims,
      totalCompensation: totalCompensation[0]?.total || 0
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch statistics', error: error.message });
  }
};
