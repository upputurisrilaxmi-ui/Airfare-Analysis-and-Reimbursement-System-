const CompensationClaim = require('../models/CompensationClaim');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { calculateCompensation, checkEligibility } = require('../utils/compensationUtils');
const { generateClaimReceipt } = require('../utils/pdfGenerator');
const { sendEmail } = require('../utils/emailService');

// Module 2 & 4: Create Compensation Claim
exports.createClaim = async (req, res) => {
  try {
    const { flightNumber, delayDuration, flightDistance, delayReason, bookingDate, documents } = req.body;
    const userId = req.userId;

    // Check eligibility
    const eligibility = checkEligibility(delayDuration, delayReason, new Date(bookingDate));
    if (!eligibility.eligible) {
      return res.status(400).json({ 
        message: 'Not eligible for compensation',
        reason: eligibility.reason 
      });
    }

    // Calculate compensation
    const compensationAmount = calculateCompensation(delayDuration, flightDistance, delayReason);

    // Create claim
    const claim = new CompensationClaim({
      userId,
      flightNumber,
      delayDuration,
      flightDistance,
      delayReason,
      compensationAmount,
      documents: documents || []
    });

    await claim.save();

    // Generate receipt
    try {
      await generateClaimReceipt(claim);
    } catch (pdfError) {
      console.log('PDF generation failed:', pdfError);
    }

    // Create notification
    const notification = new Notification({
      userId,
      type: 'success',
      title: 'Claim Submitted',
      message: `Your compensation claim for €${compensationAmount} has been submitted successfully`,
      relatedId: claim._id,
      relatedType: 'CompensationClaim'
    });
    await notification.save();

    // Send email notification
    const user = await User.findById(userId);
    if (user) {
      await sendEmail(
        user.email,
        'Compensation Claim Submitted',
        `Your claim number is ${claim.claimNumber}. Compensation amount: €${compensationAmount}`
      );
    }

    res.status(201).json({
      message: 'Compensation claim created successfully',
      claim: {
        id: claim._id,
        claimNumber: claim.claimNumber,
        status: claim.status,
        compensationAmount: claim.compensationAmount
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to create claim', error: error.message });
  }
};

// Module 4: Get User Claims
exports.getUserClaims = async (req, res) => {
  try {
    const claims = await CompensationClaim.find({ userId: req.userId })
      .sort({ claimDate: -1 });

    res.json({
      totalClaims: claims.length,
      claims: claims.map(c => ({
        id: c._id,
        claimNumber: c.claimNumber,
        flightNumber: c.flightNumber,
        compensationAmount: c.compensationAmount,
        status: c.status,
        claimDate: c.claimDate
      }))
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch claims', error: error.message });
  }
};

// Module 4: Get Claim Details
exports.getClaimDetails = async (req, res) => {
  try {
    const claim = await CompensationClaim.findById(req.params.id);
    if (!claim) {
      return res.status(404).json({ message: 'Claim not found' });
    }

    // Verify ownership
    if (claim.userId.toString() !== req.userId) {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    res.json({ claim });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch claim details', error: error.message });
  }
};

// Module 8: Upload Claim Documents
exports.uploadDocument = async (req, res) => {
  try {
    const { claimId } = req.params;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ message: 'No file provided' });
    }

    const claim = await CompensationClaim.findById(claimId);
    if (!claim) {
      return res.status(404).json({ message: 'Claim not found' });
    }

    claim.documents.push({
      fileName: file.filename,
      fileUrl: `/uploads/${file.filename}`,
      uploadedAt: new Date()
    });

    await claim.save();

    // Create notification
    const notification = new Notification({
      userId: claim.userId,
      type: 'info',
      title: 'Document Uploaded',
      message: `Document ${file.filename} has been uploaded to your claim`,
      relatedId: claim._id,
      relatedType: 'CompensationClaim'
    });
    await notification.save();

    res.json({
      message: 'Document uploaded successfully',
      document: {
        fileName: file.filename,
        fileUrl: `/uploads/${file.filename}`
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'File upload failed', error: error.message });
  }
};
