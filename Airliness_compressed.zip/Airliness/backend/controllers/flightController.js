const Flight = require('../models/Flight');
const SearchHistory = require('../models/SearchHistory');

// Module 3: Search Flights
exports.searchFlights = async (req, res) => {
  try {
    const { departure, arrival, departureDate, returnDate, passengers } = req.body;

    // Find flights matching criteria
    const flights = await Flight.find({
      'departure.city': departure,
      'arrival.city': arrival,
      'departure.time': { $gte: new Date(departureDate) }
    }).limit(100);

    // Save search history
    if (req.userId) {
      const searchRecord = new SearchHistory({
        userId: req.userId,
        departure,
        arrival,
        departureDate,
        returnDate,
        passengers,
        results: flights.map(f => f._id)
      });
      await searchRecord.save();
    }

    res.json({
      totalFlights: flights.length,
      flights: flights.map(f => ({
        id: f._id,
        flightNumber: f.flightNumber,
        airline: f.airline,
        departure: f.departure,
        arrival: f.arrival,
        duration: f.duration,
        price: f.price,
        layovers: f.layovers,
        onTimePerformance: f.onTimePerformance,
        rating: f.rating
      }))
    });
  } catch (error) {
    res.status(500).json({ message: 'Flight search failed', error: error.message });
  }
};

// Module 3: Get Flight Details
exports.getFlightDetails = async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    res.json({ flight });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch flight details', error: error.message });
  }
};

// Module 3: Filter Flights
exports.filterFlights = async (req, res) => {
  try {
    const { minPrice, maxPrice, maxLayovers, minRating, airline } = req.body;

    const filter = {};
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = minPrice;
      if (maxPrice) filter.price.$lte = maxPrice;
    }
    if (maxLayovers) filter.layovers = { $lte: maxLayovers };
    if (minRating) filter.rating = { $gte: minRating };
    if (airline) filter.airline = airline;

    const flights = await Flight.find(filter);

    res.json({
      totalFlights: flights.length,
      flights
    });
  } catch (error) {
    res.status(500).json({ message: 'Filter failed', error: error.message });
  }
};

// Module 6: Get Search History
exports.getSearchHistory = async (req, res) => {
  try {
    const history = await SearchHistory.find({ userId: req.userId })
      .populate('results')
      .sort({ createdAt: -1 })
      .limit(10);

    res.json({ searchHistory: history });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch search history', error: error.message });
  }
};
