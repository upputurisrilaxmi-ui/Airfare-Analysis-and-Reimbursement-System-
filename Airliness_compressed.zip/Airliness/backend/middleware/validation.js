const { body, validationResult } = require('express-validator');

const validateUserRegistration = [
  body('firstName').notEmpty().withMessage('First name is required'),
  body('lastName').notEmpty().withMessage('Last name is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
];

const validateFlightSearch = [
  body('departure').notEmpty().withMessage('Departure is required'),
  body('arrival').notEmpty().withMessage('Arrival is required'),
  body('departureDate').notEmpty().withMessage('Departure date is required'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
];

const validateCompensationClaim = [
  body('flightNumber').notEmpty().withMessage('Flight number is required'),
  body('delayDuration').isNumeric().withMessage('Delay duration must be numeric'),
  body('flightDistance').isNumeric().withMessage('Flight distance must be numeric'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
];

module.exports = {
  validateUserRegistration,
  validateFlightSearch,
  validateCompensationClaim
};
