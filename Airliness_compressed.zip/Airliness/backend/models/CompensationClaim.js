const mongoose = require('mongoose');

const compensationClaimSchema = new mongoose.Schema({
  claimNumber: { type: String, unique: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  flightNumber: String,
  delayDuration: { type: Number, required: true },
  flightDistance: { type: Number, required: true },
  delayReason: String,
  compensationAmount: { type: Number, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'paid'], default: 'pending' },
  documents: [{
    fileName: String,
    fileUrl: String,
    uploadedAt: Date
  }],
  claimDate: { type: Date, default: Date.now },
  approvalDate: Date,
  rejectionReason: String,
  notes: String
});

// Auto-generate claim number
compensationClaimSchema.pre('save', async function(next) {
  if (!this.claimNumber) {
    const count = await mongoose.model('CompensationClaim').countDocuments();
    this.claimNumber = `CLAIM-${Date.now()}-${count + 1}`;
  }
  next();
});

module.exports = mongoose.model('CompensationClaim', compensationClaimSchema);
