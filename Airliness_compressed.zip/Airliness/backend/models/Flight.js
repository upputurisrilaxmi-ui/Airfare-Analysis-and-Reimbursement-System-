const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
  flightNumber: { type: String, required: true, unique: true },
  airline: { type: String, required: true },
  departure: {
    airport: String,
    time: Date,
    city: String
  },
  arrival: {
    airport: String,
    time: Date,
    city: String
  },
  duration: String,
  price: { type: Number, required: true },
  seats: { type: Number, default: 100 },
  layovers: { type: Number, default: 0 },
  onTimePerformance: { type: Number, default: 85 },
  rating: { type: Number, default: 4.0 },
  aircraft: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Flight', flightSchema);
