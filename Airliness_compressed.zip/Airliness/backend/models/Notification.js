const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['success', 'error', 'info', 'warning'], default: 'info' },
  title: String,
  message: String,
  relatedId: mongoose.Schema.Types.ObjectId,
  relatedType: String,
  isRead: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: () => new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) }
});

module.exports = mongoose.model('Notification', notificationSchema);
