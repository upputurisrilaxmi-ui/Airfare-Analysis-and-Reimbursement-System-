const mongoose = require('mongoose');

const searchHistorySchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  departure: String,
  arrival: String,
  departureDate: Date,
  returnDate: Date,
  passengers: Number,
  results: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Flight' }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('SearchHistory', searchHistorySchema);
