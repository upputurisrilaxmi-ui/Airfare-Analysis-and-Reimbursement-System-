const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// Module 10: Admin Panel - All routes require admin access
router.use(authMiddleware, adminMiddleware);

// Claims management
router.get('/claims', adminController.getAllClaims);
router.put('/claims/:claimId/approve', adminController.approveClaim);
router.put('/claims/:claimId/reject', adminController.rejectClaim);

// Flight management
router.post('/flights', adminController.addFlight);
router.put('/flights/:flightId', adminController.updateFlight);
router.delete('/flights/:flightId', adminController.deleteFlight);

// Dashboard statistics
router.get('/stats', adminController.getDashboardStats);

module.exports = router;
