const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateUserRegistration } = require('../middleware/validation');
const { authMiddleware } = require('../middleware/auth');

// Module 1: Authentication & Authorization
router.post('/register', validateUserRegistration, authController.register);
router.post('/login', authController.login);

// Protected routes
router.get('/profile', authMiddleware, authController.getProfile);
router.put('/profile', authMiddleware, authController.updateProfile);

module.exports = router;
