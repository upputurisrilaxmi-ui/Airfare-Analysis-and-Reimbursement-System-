const express = require('express');
const router = express.Router();
const multer = require('multer');
const claimController = require('../controllers/claimController');
const { authMiddleware } = require('../middleware/auth');
const { validateCompensationClaim } = require('../middleware/validation');

// Configure file upload
const upload = multer({ dest: 'uploads/' });

// Module 2 & 4: Flight Delay Compensation System
router.post('/create', authMiddleware, validateCompensationClaim, claimController.createClaim);
router.get('/', authMiddleware, claimController.getUserClaims);
router.get('/:id', authMiddleware, claimController.getClaimDetails);

// Module 8: File Handling - Upload Documents
router.post('/:claimId/upload', authMiddleware, upload.single('document'), claimController.uploadDocument);

module.exports = router;
