const express = require('express');
const router = express.Router();
const flightController = require('../controllers/flightController');
const { authMiddleware } = require('../middleware/auth');
const { validateFlightSearch } = require('../middleware/validation');

// Module 3: Flight Comparison Tool & Module 6: Data Display
router.post('/search', validateFlightSearch, flightController.searchFlights);
router.get('/:id', flightController.getFlightDetails);
router.post('/filter', flightController.filterFlights);

// Module 6: Search History
router.get('/history', authMiddleware, flightController.getSearchHistory);

module.exports = router;
