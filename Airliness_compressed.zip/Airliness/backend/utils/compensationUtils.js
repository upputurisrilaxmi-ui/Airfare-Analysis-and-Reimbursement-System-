// Calculate compensation based on delay and distance
const calculateCompensation = (delayMinutes, distanceKm, delayReason) => {
  let compensation = 0;

  // If delay reason is "airline fault", full compensation applies
  // If "weather" or "force majeure", no compensation
  if (delayReason === 'weather' || delayReason === 'force_majeure') {
    return 0;
  }

  // EU Regulation 261/2004 compensation amounts
  if (distanceKm <= 1500) {
    compensation = 250;
  } else if (distanceKm <= 3500) {
    compensation = 400;
  } else {
    compensation = 600;
  }

  // Reduce compensation if delay is less than 3 hours
  if (delayMinutes < 180) {
    compensation = compensation * 0.5;
  }

  // Increase for excessive delays (more than 24 hours)
  if (delayMinutes > 1440) {
    compensation = compensation * 1.5;
  }

  return Math.round(compensation);
};

// Check eligibility for compensation
const checkEligibility = (delayMinutes, delayReason, bookingDate) => {
  const reasons = ['airline_fault', 'technical_issue', 'crew_issue', 'maintenance'];
  
  if (!reasons.includes(delayReason)) {
    return { eligible: false, reason: 'Delay reason does not qualify for compensation' };
  }

  if (delayMinutes < 180) {
    return { eligible: false, reason: 'Delay must be at least 3 hours' };
  }

  // Compensation claim must be within 6 months of booking
  const claimDeadline = new Date(bookingDate);
  claimDeadline.setMonth(claimDeadline.getMonth() + 6);
  
  if (new Date() > claimDeadline) {
    return { eligible: false, reason: 'Compensation claim expired (6 months limit)' };
  }

  return { eligible: true, reason: 'Eligible for compensation' };
};

module.exports = { calculateCompensation, checkEligibility };
