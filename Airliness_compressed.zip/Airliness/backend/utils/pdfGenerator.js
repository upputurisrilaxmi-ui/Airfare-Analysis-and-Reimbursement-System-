const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const generateClaimReceipt = (claimData) => {
  return new Promise((resolve, reject) => {
    try {
      const fileName = `claim_${claimData.claimNumber}.pdf`;
      const filePath = path.join(__dirname, '../uploads/receipts', fileName);

      // Ensure directory exists
      if (!fs.existsSync(path.join(__dirname, '../uploads/receipts'))) {
        fs.mkdirSync(path.join(__dirname, '../uploads/receipts'), { recursive: true });
      }

      const doc = new PDFDocument();
      const stream = fs.createWriteStream(filePath);

      doc.pipe(stream);

      // Header
      doc.fontSize(20).text('Compensation Claim Receipt', { align: 'center' });
      doc.moveDown();

      // Claim Details
      doc.fontSize(12).text(`Claim Number: ${claimData.claimNumber}`);
      doc.text(`Status: ${claimData.status}`);
      doc.text(`Claim Date: ${new Date(claimData.claimDate).toLocaleDateString()}`);
      doc.moveDown();

      // Flight Details
      doc.fontSize(14).text('Flight Details', { underline: true });
      doc.fontSize(12).text(`Flight Number: ${claimData.flightNumber}`);
      doc.text(`Delay Duration: ${claimData.delayDuration} minutes`);
      doc.text(`Flight Distance: ${claimData.flightDistance} km`);
      doc.moveDown();

      // Compensation Details
      doc.fontSize(14).text('Compensation Details', { underline: true });
      doc.fontSize(12).text(`Compensation Amount: €${claimData.compensationAmount}`);
      doc.text(`Delay Reason: ${claimData.delayReason}`);
      doc.moveDown();

      // Notes
      if (claimData.notes) {
        doc.fontSize(14).text('Notes', { underline: true });
        doc.fontSize(12).text(claimData.notes);
      }

      // Footer
      doc.moveDown();
      doc.fontSize(10).text('This receipt confirms your compensation claim submission.', { align: 'center' });
      doc.text('For more information, visit our website.', { align: 'center' });

      doc.end();

      stream.on('finish', () => {
        resolve(filePath);
      });
    } catch (error) {
      reject(error);
    }
  });
};

module.exports = { generateClaimReceipt };
