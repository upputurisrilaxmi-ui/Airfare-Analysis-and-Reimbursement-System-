// Sample data to seed the database

const sampleFlights = [
  {
    flightNumber: "BA123",
    airline: "British Airways",
    departure: {
      airport: "LHR",
      time: new Date("2026-06-15T10:00:00"),
      city: "London"
    },
    arrival: {
      airport: "CDG",
      time: new Date("2026-06-15T13:00:00"),
      city: "Paris"
    },
    duration: "2h 30m",
    price: 150,
    seats: 150,
    layovers: 0,
    onTimePerformance: 92,
    rating: 4.5,
    aircraft: "Boeing 787"
  },
  {
    flightNumber: "EZ456",
    airline: "EasyJet",
    departure: {
      airport: "LGW",
      time: new Date("2026-06-15T08:00:00"),
      city: "London"
    },
    arrival: {
      airport: "CDG",
      time: new Date("2026-06-15T11:00:00"),
      city: "Paris"
    },
    duration: "2h 15m",
    price: 89,
    seats: 180,
    layovers: 0,
    onTimePerformance: 88,
    rating: 3.8,
    aircraft: "Airbus A320"
  },
  {
    flightNumber: "AF789",
    airline: "Air France",
    departure: {
      airport: "CDG",
      time: new Date("2026-06-15T14:00:00"),
      city: "Paris"
    },
    arrival: {
      airport: "FCO",
      time: new Date("2026-06-15T16:30:00"),
      city: "Rome"
    },
    duration: "2h 15m",
    price: 120,
    seats: 200,
    layovers: 0,
    onTimePerformance: 94,
    rating: 4.6,
    aircraft: "Airbus A380"
  }
];

module.exports = { sampleFlights };
