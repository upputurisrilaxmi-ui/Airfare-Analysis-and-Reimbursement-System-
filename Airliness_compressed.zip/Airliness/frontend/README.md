# Airfare Analysis - Frontend Documentation

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm start
```

Frontend runs on: `http://localhost:3000`

### 3. Build for Production
```bash
npm run build
```

## Project Structure

```
src/
├── components/          # Reusable React components
│   ├── LoginForm.js
│   ├── RegisterForm.js
│   ├── FlightSearchForm.js
│   ├── FlightResults.js
│   ├── CompensationForm.js
│   ├── NotificationCenter.js
│   └── AdminDashboard.js
│
├── pages/              # Page-level components
│   ├── Login.js
│   ├── Register.js
│   ├── Dashboard.js
│   ├── Claims.js
│   ├── Notifications.js
│   ├── Profile.js
│   └── AdminPanel.js
│
├── styles/             # CSS modules
│   ├── Auth.css
│   ├── Dashboard.css
│   ├── FlightSearch.css
│   ├── FlightResults.css
│   ├── CompensationForm.css
│   ├── Claims.css
│   ├── Notifications.css
│   ├── AdminDashboard.css
│   ├── Profile.css
│   └── AdminPanel.css
│
├── utils/              # Utility functions
│   ├── api.js          # Axios instance and API calls
│   └── authContext.js  # Authentication context
│
├── App.js              # Main app component
├── App.css             # Global styles
└── index.js            # Entry point
```

## Available Routes

- `/` - Redirects to dashboard
- `/login` - Login page
- `/register` - Registration page
- `/dashboard` - Flight search and comparison
- `/claims` - Compensation claims management
- `/notifications` - Notification center
- `/profile` - User profile management
- `/admin` - Admin dashboard (admin only)

## Components

### LoginForm
User login with email and password

### RegisterForm
New user registration

### FlightSearchForm
Search flights by routes and dates

### FlightResults
Display search results in card format

### CompensationForm
File new compensation claims

### NotificationCenter
View and manage notifications

### AdminDashboard
Admin panel for claim review and flight management

## Authentication Flow

1. User registers or logs in
2. JWT token stored in localStorage
3. Token added to all API requests via axios interceptor
4. Protected routes redirect to login if no token

## API Integration

API base URL: `http://localhost:5000/api`

All API calls use Axios with automatic token injection:
```javascript
const response = await flightAPI.searchFlights(data);
```

## Styling

Using CSS modules with BEM naming convention. Color scheme:
- Primary: #667eea
- Secondary: #764ba2
- Success: #2ecc71
- Error: #e74c3c
- Warning: #ff9800

## Environment Variables

Create `.env` file (optional):
```
REACT_APP_API_URL=http://localhost:5000/api
```

## Features Implemented

✅ User Authentication
✅ Flight Search and Comparison
✅ Compensation Claim Filing
✅ Document Upload
✅ Notifications System
✅ Admin Dashboard
✅ Profile Management
✅ Responsive Design
✅ Error Handling
✅ Loading States

## Testing the Application

### Test User Registration
1. Go to `/register`
2. Fill in user details
3. Submit form
4. Redirected to dashboard

### Test Flight Search
1. On dashboard, enter search criteria
2. Select departure and arrival cities
3. Choose dates
4. Click "Search Flights"
5. View results

### Test Compensation Claim
1. Go to `/claims`
2. Fill claim form with flight details
3. Enter delay duration and distance
4. Submit claim
5. View claim status

### Admin Operations
1. Login as admin
2. Go to `/admin`
3. Review pending claims
4. Approve or reject claims
5. Manage flights

## Troubleshooting

**API connection refused**
- Ensure backend is running on port 5000

**Blank screen after login**
- Check browser console for errors
- Verify token in localStorage

**Images not loading**
- Check public folder path

## Performance Tips

- Components are lightweight and optimized
- API calls use proper loading states
- CSS is minimized and optimized
- Lazy loading for routes available

## Future Enhancements

- Dark mode theme
- Advanced filters
- Favorites/Wishlist
- Booking integration
- Map visualization
- Real-time notifications
