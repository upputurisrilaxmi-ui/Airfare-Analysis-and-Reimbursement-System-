import React, { useState, useEffect } from 'react';
import { adminAPI } from '../utils/api';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [claims, setClaims] = useState([]);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [actionNotes, setActionNotes] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const statsResponse = await adminAPI.getDashboardStats();
      setStats(statsResponse.data);

      const claimsResponse = await adminAPI.getAllClaims({ status: 'pending' });
      setClaims(claimsResponse.data.claims);
    } catch (error) {
      alert('Failed to fetch dashboard data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveClaim = async (claimId) => {
    try {
      await adminAPI.approveClaim(claimId, { approvalNotes: actionNotes });
      alert('Claim approved successfully');
      setActionNotes('');
      setSelectedClaim(null);
      fetchDashboardData();
    } catch (error) {
      alert('Failed to approve claim: ' + error.message);
    }
  };

  const handleRejectClaim = async (claimId) => {
    try {
      await adminAPI.rejectClaim(claimId, { rejectionReason: actionNotes });
      alert('Claim rejected successfully');
      setActionNotes('');
      setSelectedClaim(null);
      fetchDashboardData();
    } catch (error) {
      alert('Failed to reject claim: ' + error.message);
    }
  };

  if (loading) return <div className="loading">Loading admin dashboard...</div>;

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>

      {stats && (
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Total Users</h3>
            <p className="stat-value">{stats.totalUsers}</p>
          </div>
          <div className="stat-card">
            <h3>Total Flights</h3>
            <p className="stat-value">{stats.totalFlights}</p>
          </div>
          <div className="stat-card">
            <h3>Total Claims</h3>
            <p className="stat-value">{stats.totalClaims}</p>
          </div>
          <div className="stat-card">
            <h3>Pending Claims</h3>
            <p className="stat-value" style={{ color: '#ff9800' }}>{stats.pendingClaims}</p>
          </div>
          <div className="stat-card">
            <h3>Approved Claims</h3>
            <p className="stat-value" style={{ color: '#4caf50' }}>{stats.approvedClaims}</p>
          </div>
          <div className="stat-card">
            <h3>Total Compensation</h3>
            <p className="stat-value">€{stats.totalCompensation}</p>
          </div>
        </div>
      )}

      <div className="claims-section">
        <h2>Pending Claims</h2>
        <div className="claims-list">
          {claims.map((claim) => (
            <div key={claim._id} className="claim-item">
              <div>
                <h3>Claim #{claim.claimNumber}</h3>
                <p><strong>Passenger:</strong> {claim.userId?.firstName} {claim.userId?.lastName}</p>
                <p><strong>Flight:</strong> {claim.flightNumber}</p>
                <p><strong>Amount:</strong> €{claim.compensationAmount}</p>
              </div>
              <button onClick={() => setSelectedClaim(claim._id)}>Review</button>
            </div>
          ))}
        </div>

        {selectedClaim && (
          <div className="modal">
            <div className="modal-content">
              <h3>Claim Decision</h3>
              <textarea
                placeholder="Add notes..."
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
              />
              <div className="modal-buttons">
                <button onClick={() => handleApproveClaim(selectedClaim)} className="approve-btn">
                  Approve
                </button>
                <button onClick={() => handleRejectClaim(selectedClaim)} className="reject-btn">
                  Reject
                </button>
                <button onClick={() => setSelectedClaim(null)} className="cancel-btn">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
