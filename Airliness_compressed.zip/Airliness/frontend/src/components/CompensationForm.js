import React, { useState } from 'react';
import { claimAPI } from '../utils/api';
import '../styles/CompensationForm.css';

const CompensationForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    flightNumber: '',
    delayDuration: '',
    flightDistance: '',
    delayReason: 'airline_fault',
    bookingDate: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await claimAPI.createClaim(formData);
      setMessage('Claim submitted successfully! Claim #: ' + response.data.claim.claimNumber);
      setFormData({
        flightNumber: '',
        delayDuration: '',
        flightDistance: '',
        delayReason: 'airline_fault',
        bookingDate: ''
      });
      if (onSubmit) onSubmit(response.data.claim);
    } catch (error) {
      setMessage('Error: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="compensation-form-container">
      <h2>File Compensation Claim</h2>
      {message && <div className={`message ${message.includes('successfully') ? 'success' : 'error'}`}>{message}</div>}
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="flightNumber"
          placeholder="Flight Number"
          value={formData.flightNumber}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="delayDuration"
          placeholder="Delay Duration (minutes)"
          value={formData.delayDuration}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="flightDistance"
          placeholder="Flight Distance (km)"
          value={formData.flightDistance}
          onChange={handleChange}
          required
        />
        <select
          name="delayReason"
          value={formData.delayReason}
          onChange={handleChange}
        >
          <option value="airline_fault">Airline Fault</option>
          <option value="technical_issue">Technical Issue</option>
          <option value="crew_issue">Crew Issue</option>
          <option value="maintenance">Maintenance</option>
          <option value="weather">Weather</option>
          <option value="force_majeure">Force Majeure</option>
        </select>
        <input
          type="date"
          name="bookingDate"
          value={formData.bookingDate}
          onChange={handleChange}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit Claim'}
        </button>
      </form>
    </div>
  );
};

export default CompensationForm;
