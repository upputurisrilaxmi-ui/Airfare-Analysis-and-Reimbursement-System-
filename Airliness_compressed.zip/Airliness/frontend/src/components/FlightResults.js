import React from 'react';
import '../styles/FlightResults.css';

const FlightResults = ({ flights, loading }) => {
  if (loading) return <div className="loading">Loading flights...</div>;
  if (!flights || flights.length === 0) return <div className="no-results">No flights found</div>;

  return (
    <div className="flight-results">
      {flights.map((flight) => (
        <div key={flight.id} className="flight-card">
          <div className="flight-header">
            <h3>{flight.airline}</h3>
            <span className="price">€{flight.price}</span>
          </div>
          <div className="flight-details">
            <div className="route">
              <div className="airport">
                <p className="time">{new Date(flight.departure.time).toLocaleTimeString()}</p>
                <p className="code">{flight.departure.airport}</p>
              </div>
              <div className="duration">
                <p>{flight.duration}</p>
                <div className="line"></div>
              </div>
              <div className="airport">
                <p className="time">{new Date(flight.arrival.time).toLocaleTimeString()}</p>
                <p className="code">{flight.arrival.airport}</p>
              </div>
            </div>
          </div>
          <div className="flight-info">
            <span>✈ {flight.flightNumber}</span>
            <span>🔄 {flight.layovers} layovers</span>
            <span>⏱ {flight.onTimePerformance}% on-time</span>
            <span>⭐ {flight.rating}/5</span>
          </div>
          <button className="select-btn">Select Flight</button>
        </div>
      ))}
    </div>
  );
};

export default FlightResults;
