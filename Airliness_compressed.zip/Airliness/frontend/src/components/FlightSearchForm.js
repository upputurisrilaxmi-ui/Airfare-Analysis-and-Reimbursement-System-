import React, { useState } from 'react';
import { flightAPI } from '../utils/api';
import '../styles/FlightSearch.css';

const FlightSearchForm = ({ onSearch }) => {
  const [formData, setFormData] = useState({
    departure: '',
    arrival: '',
    departureDate: '',
    returnDate: '',
    passengers: 1
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await flightAPI.searchFlights(formData);
      onSearch(response.data.flights);
    } catch (error) {
      alert('Search failed: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="flight-search-form" onSubmit={handleSubmit}>
      <input
        type="text"
        name="departure"
        placeholder="From (City)"
        value={formData.departure}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="arrival"
        placeholder="To (City)"
        value={formData.arrival}
        onChange={handleChange}
        required
      />
      <input
        type="date"
        name="departureDate"
        value={formData.departureDate}
        onChange={handleChange}
        required
      />
      <input
        type="date"
        name="returnDate"
        value={formData.returnDate}
        onChange={handleChange}
      />
      <input
        type="number"
        name="passengers"
        placeholder="Passengers"
        value={formData.passengers}
        onChange={handleChange}
        min="1"
        required
      />
      <button type="submit" disabled={loading}>
        {loading ? 'Searching...' : 'Search Flights'}
      </button>
    </form>
  );
};

export default FlightSearchForm;
