import React, { useState, useEffect } from 'react';
import { notificationAPI } from '../utils/api';
import '../styles/Notifications.css';

const NotificationCenter = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const response = await notificationAPI.getNotifications();
      setNotifications(response.data.notifications);
      
      const unreadResponse = await notificationAPI.getUnreadCount();
      setUnreadCount(unreadResponse.data.unreadCount);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id) => {
    try {
      await notificationAPI.markAsRead(id);
      setNotifications(notifications.map(n => n._id === id ? { ...n, isRead: true } : n));
      setUnreadCount(Math.max(0, unreadCount - 1));
    } catch (error) {
      console.error('Failed to mark as read:', error);
    }
  };

  const handleDeleteNotification = async (id) => {
    try {
      await notificationAPI.deleteNotification(id);
      const notification = notifications.find(n => n._id === id);
      setNotifications(notifications.filter(n => n._id !== id));
      if (!notification?.isRead) {
        setUnreadCount(Math.max(0, unreadCount - 1));
      }
    } catch (error) {
      console.error('Failed to delete notification:', error);
    }
  };

  return (
    <div className="notification-center">
      <div className="notification-header">
        <h3>Notifications ({unreadCount} unread)</h3>
        {unreadCount > 0 && (
          <button onClick={() => notificationAPI.markAllAsRead().then(fetchNotifications)}>
            Mark All as Read
          </button>
        )}
      </div>

      {loading ? (
        <div className="loading">Loading notifications...</div>
      ) : notifications.length === 0 ? (
        <div className="no-notifications">No notifications</div>
      ) : (
        <div className="notification-list">
          {notifications.map((notification) => (
            <div key={notification._id} className={`notification-item ${notification.type} ${!notification.isRead ? 'unread' : ''}`}>
              <div className="notification-content">
                <h4>{notification.title}</h4>
                <p>{notification.message}</p>
                <small>{new Date(notification.createdAt).toLocaleString()}</small>
              </div>
              <div className="notification-actions">
                {!notification.isRead && (
                  <button onClick={() => handleMarkAsRead(notification._id)}>Mark Read</button>
                )}
                <button onClick={() => handleDeleteNotification(notification._id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;
