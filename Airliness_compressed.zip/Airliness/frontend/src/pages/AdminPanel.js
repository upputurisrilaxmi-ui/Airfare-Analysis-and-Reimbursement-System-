import React from 'react';
import AdminDashboard from '../components/AdminDashboard';
import '../styles/AdminPanel.css';

const AdminPanel = () => {
  return (
    <div className="admin-panel-page">
      <AdminDashboard />
    </div>
  );
};

export default AdminPanel;
