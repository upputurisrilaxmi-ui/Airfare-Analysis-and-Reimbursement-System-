import React, { useState, useEffect } from 'react';
import { claimAPI } from '../utils/api';
import CompensationForm from '../components/CompensationForm';
import '../styles/Claims.css';

const Claims = () => {
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchClaims();
  }, []);

  const fetchClaims = async () => {
    setLoading(true);
    try {
      const response = await claimAPI.getUserClaims();
      setClaims(response.data.claims);
    } catch (error) {
      alert('Failed to fetch claims: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="claims-page">
      <div className="claims-header">
        <h1>💰 Compensation Claims</h1>
        <p>File and track your flight delay compensation claims</p>
      </div>

      <div className="claims-container">
        <div className="claim-form-section">
          <CompensationForm onSubmit={fetchClaims} />
        </div>

        <div className="claims-list-section">
          <h2>Your Claims</h2>
          {loading ? (
            <div className="loading">Loading claims...</div>
          ) : claims.length === 0 ? (
            <div className="no-claims">No claims yet. File one above!</div>
          ) : (
            <div className="claims-list">
              {claims.map((claim) => (
                <div key={claim.id} className={`claim-card status-${claim.status}`}>
                  <div className="claim-header">
                    <span className="claim-number">{claim.claimNumber}</span>
                    <span className={`status ${claim.status}`}>{claim.status.toUpperCase()}</span>
                  </div>
                  <div className="claim-details">
                    <p><strong>Flight:</strong> {claim.flightNumber}</p>
                    <p><strong>Amount:</strong> €{claim.compensationAmount}</p>
                    <p><strong>Date:</strong> {new Date(claim.claimDate).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Claims;
