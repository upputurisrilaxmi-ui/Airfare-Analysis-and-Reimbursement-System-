import React, { useState } from 'react';
import FlightSearchForm from '../components/FlightSearchForm';
import FlightResults from '../components/FlightResults';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = (searchResults) => {
    setFlights(searchResults);
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>🛫 Flight Comparison Tool</h1>
        <p>Find and compare flights across airlines</p>
      </div>

      <div className="dashboard-content">
        <div className="search-section">
          <FlightSearchForm onSearch={handleSearch} />
        </div>

        <div className="results-section">
          <FlightResults flights={flights} loading={loading} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
