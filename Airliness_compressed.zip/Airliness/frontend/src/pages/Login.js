import React from 'react';
import { useAuth } from '../utils/authContext';
import LoginForm from '../components/LoginForm';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (credentials) => {
    await login(credentials.email, credentials.password);
    navigate('/dashboard');
  };

  return <LoginForm onSubmit={handleLogin} loading={false} />;
};

export default Login;
