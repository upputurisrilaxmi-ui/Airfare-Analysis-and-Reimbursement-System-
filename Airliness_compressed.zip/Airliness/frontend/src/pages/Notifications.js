import React from 'react';
import NotificationCenter from '../components/NotificationCenter';
import '../styles/Notifications.css';

const Notifications = () => {
  return (
    <div className="notifications-page">
      <NotificationCenter />
    </div>
  );
};

export default Notifications;
