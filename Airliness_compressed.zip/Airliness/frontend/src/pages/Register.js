import React from 'react';
import { useAuth } from '../utils/authContext';
import RegisterForm from '../components/RegisterForm';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleRegister = async (userData) => {
    await register(userData);
    navigate('/dashboard');
  };

  return <RegisterForm onSubmit={handleRegister} loading={false} />;
};

export default Register;
