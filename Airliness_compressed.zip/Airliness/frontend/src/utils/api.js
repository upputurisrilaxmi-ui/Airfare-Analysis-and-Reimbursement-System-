import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getProfile: () => api.get('/auth/profile'),
  updateProfile: (data) => api.put('/auth/profile', data)
};

// Flight API
export const flightAPI = {
  searchFlights: (data) => api.post('/flights/search', data),
  getFlightDetails: (id) => api.get(`/flights/${id}`),
  filterFlights: (data) => api.post('/flights/filter', data),
  getSearchHistory: () => api.get('/flights/history')
};

// Claims API
export const claimAPI = {
  createClaim: (data) => api.post('/claims/create', data),
  getUserClaims: () => api.get('/claims'),
  getClaimDetails: (id) => api.get(`/claims/${id}`),
  uploadDocument: (claimId, file) => {
    const formData = new FormData();
    formData.append('document', file);
    return api.post(`/claims/${claimId}/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  }
};

// Notifications API
export const notificationAPI = {
  getNotifications: () => api.get('/notifications'),
  markAsRead: (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: () => api.put('/notifications/mark-all-read'),
  deleteNotification: (id) => api.delete(`/notifications/${id}`),
  getUnreadCount: () => api.get('/notifications/unread-count')
};

// Admin API
export const adminAPI = {
  getAllClaims: (params) => api.get('/admin/claims', { params }),
  approveClaim: (id, data) => api.put(`/admin/claims/${id}/approve`, data),
  rejectClaim: (id, data) => api.put(`/admin/claims/${id}/reject`, data),
  addFlight: (data) => api.post('/admin/flights', data),
  updateFlight: (id, data) => api.put(`/admin/flights/${id}`, data),
  deleteFlight: (id) => api.delete(`/admin/flights/${id}`),
  getDashboardStats: () => api.get('/admin/stats')
};

export default api;
